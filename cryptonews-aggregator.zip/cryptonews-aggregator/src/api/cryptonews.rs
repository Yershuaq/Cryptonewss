use reqwest;
use serde_json::Value;
use std::env;
use std::error::Error;
use std::fmt;

#[derive(Debug)]
pub struct NewsError {
    message: String,
}

impl fmt::Display for NewsError {
    fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
        write!(f, "{}", self.message)
    }
}

impl Error for NewsError {}

use crate::models::news::NewsItem;

pub async fn fetch_crypto_news(
    symbol: &str,
    limit: Option<u32>,
    category: Option<&str>,
) -> Result<Vec<NewsItem>, Box<dyn Error>> {
    let api_key = env::var("NEWS_API_KEY").map_err(|_| NewsError {
        message: "API key not set".to_string(),
    })?;

    let limit = limit.unwrap_or(10);
    let category = category.unwrap_or("business");

    // Формируем поисковый запрос для криптовалюты
    let query = format!("cryptocurrency OR {} OR bitcoin", symbol.to_lowercase());
    
    let url = format!(
        "https://newsapi.org/v2/everything?q={}&language=en&sortBy=publishedAt&pageSize={}&apiKey={}",
        query, limit, api_key
    );

    let resp = reqwest::get(&url)
        .await?
        .json::<Value>()
        .await?;

    if let Some(error) = resp.get("error") {
        return Err(Box::new(NewsError {
            message: error.as_str().unwrap_or("Unknown API error").to_string(),
        }));
    }

    let mut news_list = vec![];
    if let Some(articles) = resp.get("articles").and_then(|d| d.as_array()) {
        for article in articles {
            let title = article.get("title").and_then(|v| v.as_str()).unwrap_or("").to_string();
            let source = article.get("source")
                .and_then(|s| s.get("name"))
                .and_then(|v| v.as_str())
                .unwrap_or("")
                .to_string();
            let date = article.get("publishedAt").and_then(|v| v.as_str()).unwrap_or("").to_string();
            let summary = article.get("description").and_then(|v| v.as_str()).unwrap_or("").to_string();
            let url = article.get("url").and_then(|v| v.as_str()).unwrap_or("").to_string();

            news_list.push(NewsItem {
                title,
                source,
                date,
                summary,
                url,
                symbol: Some(symbol.to_string()),
                sentiment: None,
            });
        }
    }

    Ok(news_list)
}
