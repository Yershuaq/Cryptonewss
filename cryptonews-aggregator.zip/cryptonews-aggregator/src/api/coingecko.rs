use reqwest;
use serde_json::Value;
use crate::models::news::NewsItem;
use std::error::Error;
use std::fmt;

#[derive(Debug)]
pub struct PriceError {
    message: String,
}

impl fmt::Display for PriceError {
    fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
        write!(f, "{}", self.message)
    }
}

impl Error for PriceError {}

#[derive(Debug, serde::Serialize)]
pub struct CryptoPrice {
    pub symbol: String,
    pub name: String,
    pub current_price: f64,
    pub price_change_24h: f64,
    pub market_cap: f64,
    pub market_cap_rank: i32,
}

pub async fn fetch_coingecko_data(coin: &str) -> Result<Vec<NewsItem>, reqwest::Error> {
    let coin_id = coin.to_lowercase();

    // 1. Получаем описание
    let desc_url = format!("https://api.coingecko.com/api/v3/coins/{}", coin_id);
    let desc_resp = reqwest::get(&desc_url).await?.json::<Value>().await;

    // 2. Получаем цену
    let price_url = format!(
        "https://api.coingecko.com/api/v3/simple/price?ids={}&vs_currencies=usd",
        coin_id
    );
    let price_resp = reqwest::get(&price_url).await?.json::<Value>().await;

    let mut news_list = Vec::new();

    // Добавляем описание, если есть
    if let Ok(desc_json) = &desc_resp {
        if let Some(desc) = desc_json["description"]["en"].as_str() {
            news_list.push(NewsItem {
                title: format!("About {}", coin.to_uppercase()),
                source: "CoinGecko (Description)".to_string(),
                date: "N/A".to_string(),
                summary: desc.to_string(),
                url: desc_json["links"]["homepage"][0].as_str().unwrap_or("").to_string(),
            });
        }
    }

    // Добавляем цену, если есть
    if let Ok(price_json) = &price_resp {
        if let Some(price) = price_json[&coin_id]["usd"].as_f64() {
            news_list.push(NewsItem {
                title: format!("Current Price of {}", coin.to_uppercase()),
                source: "CoinGecko (Price)".to_string(),
                date: "N/A".to_string(),
                summary: format!("${:.2}", price),
                url: "https://www.coingecko.com".to_string(),
            });
        }
    }

    Ok(news_list)
}

pub async fn fetch_crypto_price(symbol: &str) -> Result<CryptoPrice, Box<dyn Error>> {
    // Преобразуем символ в формат CoinGecko (например, BTC -> bitcoin)
    let coin_id = match symbol.to_lowercase().as_str() {
        "btc" => "bitcoin",
        "eth" => "ethereum",
        "usdt" => "tether",
        "bnb" => "binancecoin",
        "sol" => "solana",
        "xrp" => "ripple",
        "ada" => "cardano",
        "doge" => "dogecoin",
        _ => return Err(Box::new(PriceError {
            message: format!("Неподдерживаемая криптовалюта: {}", symbol)
        }))
    };

    let url = format!(
        "https://api.coingecko.com/api/v3/simple/price?ids={}&vs_currencies=usd&include_24hr_change=true&include_market_cap=true&include_market_cap_rank=true",
        coin_id
    );

    let resp = reqwest::get(&url)
        .await?
        .json::<Value>()
        .await?;

    let price_data = resp.get(coin_id).ok_or_else(|| PriceError {
        message: "Не удалось получить данные о цене".to_string()
    })?;

    Ok(CryptoPrice {
        symbol: symbol.to_uppercase(),
        name: coin_id.to_string(),
        current_price: price_data["usd"].as_f64().unwrap_or(0.0),
        price_change_24h: price_data["usd_24h_change"].as_f64().unwrap_or(0.0),
        market_cap: price_data["usd_market_cap"].as_f64().unwrap_or(0.0),
        market_cap_rank: price_data["market_cap_rank"].as_i64().unwrap_or(0) as i32,
    })
}

pub async fn fetch_top_cryptos(limit: u32) -> Result<Vec<CryptoPrice>, Box<dyn Error>> {
    let url = format!(
        "https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&order=market_cap_desc&per_page={}&page=1&sparkline=false",
        limit
    );

    let resp = reqwest::get(&url)
        .await?
        .json::<Vec<Value>>()
        .await?;

    let mut prices = Vec::new();
    for coin in resp {
        prices.push(CryptoPrice {
            symbol: coin["symbol"].as_str().unwrap_or("").to_uppercase(),
            name: coin["name"].as_str().unwrap_or("").to_string(),
            current_price: coin["current_price"].as_f64().unwrap_or(0.0),
            price_change_24h: coin["price_change_percentage_24h"].as_f64().unwrap_or(0.0),
            market_cap: coin["market_cap"].as_f64().unwrap_or(0.0),
            market_cap_rank: coin["market_cap_rank"].as_i64().unwrap_or(0) as i32,
        });
    }

    Ok(prices)
}
