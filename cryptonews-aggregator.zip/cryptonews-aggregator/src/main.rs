use actix_files::Files;
use actix_web::{web, App, HttpServer, HttpResponse, Responder};
use dotenv::dotenv;
use tera::{Tera, Context};
use std::sync::Arc;
use tokio::sync::Mutex;

mod api;
mod handlers;
mod models;
mod utils;

use handlers::news_handler::{RateLimiter, search_news, get_news_by_symbol};
use handlers::price_handler::{get_crypto_price, get_top_cryptos};

// 👇 Главная HTML-страница с формой поиска
async fn index(tmpl: web::Data<Tera>) -> impl Responder {
    let ctx = Context::new();
    let rendered = tmpl.render("index.html", &ctx).unwrap();
    HttpResponse::Ok().body(rendered)
}

#[actix_web::main]
async fn main() -> std::io::Result<()> {
    dotenv().ok();
    println!("🚀 Сервер запущен: http://127.0.0.1:8080");

    // Инициализация шаблонов Tera
    let tera = Tera::new("src/templates/**/*.html")?;

    // Инициализация ограничителя скорости
    let rate_limiter = web::Data::new(Arc::new(Mutex::new(RateLimiter::new())));

    HttpServer::new(move || {
        App::new()
            .app_data(web::Data::new(tera.clone()))
            .app_data(rate_limiter.clone())
            .route("/", web::get().to(index))
            .route("/search", web::post().to(search_news))
            .route("/news/{symbol}", web::get().to(get_news_by_symbol))
            // 🔥 Подключение CSS-файлов из /static
            .service(Files::new("/static", "./static").show_files_listing())
            .service(
                web::scope("/api")
                    .service(
                        web::scope("/news")
                            .route("/search", web::post().to(search_news))
                            .route("/{symbol}", web::get().to(get_news_by_symbol))
                    )
                    .service(
                        web::scope("/prices")
                            .route("/{symbol}", web::get().to(get_crypto_price))
                            .route("/top", web::get().to(get_top_cryptos))
                    )
            )
    })
    .bind(("127.0.0.1", 8080))?
    .run()
    .await
}
