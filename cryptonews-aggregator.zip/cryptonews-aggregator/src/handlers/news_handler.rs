use actix_web::{web, HttpResponse, Responder};
use crate::api::coingecko;
use tera::Tera;
use serde::Deserialize;
use tera::Context;
use crate::models::news::{NewsItem, NewsSearchParams};
use crate::api::cryptonews::fetch_crypto_news;
use std::sync::Arc;
use tokio::sync::Mutex;
use std::time::{Duration, Instant};

const RATE_LIMIT: Duration = Duration::from_secs(1);
const MAX_REQUESTS: u32 = 10;

pub struct RateLimiter {
    last_request: Instant,
    request_count: u32,
}

impl RateLimiter {
    pub fn new() -> Self {
        RateLimiter {
            last_request: Instant::now(),
            request_count: 0,
        }
    }

    pub fn check(&mut self) -> bool {
        let now = Instant::now();
        if now.duration_since(self.last_request) >= RATE_LIMIT {
            self.request_count = 0;
            self.last_request = now;
        }
        
        if self.request_count < MAX_REQUESTS {
            self.request_count += 1;
            true
        } else {
            false
        }
    }
}

#[derive(Deserialize)]
pub struct SearchQuery {
    pub symbol: String,
}

// ✅ Для формы POST /search
pub async fn search(
    form: web::Form<SearchQuery>,
    tmpl: web::Data<Tera>,
) -> impl Responder {
    let news = coingecko::fetch_coingecko_data(&form.symbol).await.unwrap_or(vec![]);

    let mut ctx = Context::new();
    ctx.insert("symbol", &form.symbol);
    ctx.insert("news", &news);

    let rendered = tmpl.render("result.html", &ctx).unwrap();
    HttpResponse::Ok().body(rendered)
}

// ✅ Для GET /news/{symbol} — старый JSON
pub async fn get_news(path: web::Path<String>) -> impl Responder {
    let symbol = path.into_inner();

    match coingecko::fetch_coingecko_data(&symbol).await {
        Ok(news) => HttpResponse::Ok().json(news),
        Err(_) => HttpResponse::InternalServerError().body("Ошибка при получении данных"),
    }
}

pub async fn search_news(
    params: web::Json<NewsSearchParams>,
    rate_limiter: web::Data<Arc<Mutex<RateLimiter>>>,
) -> impl Responder {
    let mut limiter = rate_limiter.lock().await;
    if !limiter.check() {
        return HttpResponse::TooManyRequests().json(serde_json::json!({
            "error": "Rate limit exceeded. Please try again later."
        }));
    }

    match fetch_crypto_news(&params.query, params.limit, params.category.as_deref()).await {
        Ok(news) => HttpResponse::Ok().json(news),
        Err(e) => HttpResponse::InternalServerError().json(serde_json::json!({
            "error": e.to_string()
        }))
    }
}

pub async fn get_news_by_symbol(
    symbol: web::Path<String>,
    rate_limiter: web::Data<Arc<Mutex<RateLimiter>>>,
) -> impl Responder {
    let mut limiter = rate_limiter.lock().await;
    if !limiter.check() {
        return HttpResponse::TooManyRequests().json(serde_json::json!({
            "error": "Rate limit exceeded. Please try again later."
        }));
    }

    match fetch_crypto_news(&symbol, Some(10), Some("general")).await {
        Ok(news) => HttpResponse::Ok().json(news),
        Err(e) => HttpResponse::InternalServerError().json(serde_json::json!({
            "error": e.to_string()
        }))
    }
}
