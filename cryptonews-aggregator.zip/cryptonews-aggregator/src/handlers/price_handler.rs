use actix_web::{web, HttpResponse, Responder};
use crate::api::coingecko::{fetch_crypto_price, fetch_top_cryptos};

pub async fn get_crypto_price(symbol: web::Path<String>) -> impl Responder {
    match fetch_crypto_price(&symbol).await {
        Ok(price) => HttpResponse::Ok().json(price),
        Err(e) => HttpResponse::BadRequest().json(serde_json::json!({
            "error": e.to_string()
        }))
    }
}

pub async fn get_top_cryptos(limit: web::Query<u32>) -> impl Responder {
    match fetch_top_cryptos(limit.0).await {
        Ok(prices) => HttpResponse::Ok().json(prices),
        Err(e) => HttpResponse::InternalServerError().json(serde_json::json!({
            "error": e.to_string()
        }))
    }
} 