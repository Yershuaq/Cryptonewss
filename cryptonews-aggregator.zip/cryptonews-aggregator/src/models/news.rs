use serde::{Deserialize, Serialize};

#[derive(Debug, Serialize, Deserialize, Clone)]
pub struct NewsItem {
    pub title: String,
    pub source: String,
    pub date: String,
    pub summary: String,
    pub url: String,
    pub symbol: Option<String>,
    pub sentiment: Option<String>,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct NewsSearchParams {
    pub query: String,
    pub limit: Option<u32>,
    pub category: Option<String>,
    pub from_date: Option<String>,
    pub to_date: Option<String>,
}
